package com.luisdeveloper.billeteravirtualuq.controller.services;

public interface IBilleteraVirtualUqControllerService {
}
