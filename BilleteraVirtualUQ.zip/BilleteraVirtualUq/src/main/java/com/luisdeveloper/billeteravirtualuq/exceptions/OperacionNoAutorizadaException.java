package com.luisdeveloper.billeteravirtualuq.exceptions;

public class OperacionNoAutorizadaException extends Exception {

    public OperacionNoAutorizadaException(String mensaje) {
        super(mensaje);
    }
}
