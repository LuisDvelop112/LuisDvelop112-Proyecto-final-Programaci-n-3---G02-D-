package com.luisdeveloper.billeteravirtualuq.exceptions;

public class SaldoInsuficienteException extends Exception {

    public SaldoInsuficienteException(String mensaje) {
        super(mensaje);
    }
}
