package com.luisdeveloper.billeteravirtualuq.exceptions;

public class UsuarioNoEncontradoException extends Exception {

    public UsuarioNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
