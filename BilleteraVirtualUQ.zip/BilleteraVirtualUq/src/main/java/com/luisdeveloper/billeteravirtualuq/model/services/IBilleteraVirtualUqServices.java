package com.luisdeveloper.billeteravirtualuq.model.services;

public interface IBilleteraVirtualUqServices {

}
