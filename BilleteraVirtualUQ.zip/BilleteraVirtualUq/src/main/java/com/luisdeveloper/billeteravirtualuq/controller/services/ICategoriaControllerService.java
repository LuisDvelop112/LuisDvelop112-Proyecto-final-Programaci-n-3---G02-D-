package com.luisdeveloper.billeteravirtualuq.controller.services;

import com.luisdeveloper.billeteravirtualuq.model.Categoria;

public interface ICategoriaControllerService {

    public Categoria buscarCategoria(String idCategoria);
}
