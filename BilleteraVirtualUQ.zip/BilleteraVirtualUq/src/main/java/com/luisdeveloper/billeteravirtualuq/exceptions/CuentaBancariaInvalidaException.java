package com.luisdeveloper.billeteravirtualuq.exceptions;

public class CuentaBancariaInvalidaException extends Exception {

    public CuentaBancariaInvalidaException(String mensaje) {
        super(mensaje);
    }
}
