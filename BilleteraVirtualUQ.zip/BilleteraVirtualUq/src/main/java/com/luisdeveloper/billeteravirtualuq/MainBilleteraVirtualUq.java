package com.luisdeveloper.billeteravirtualuq;

import com.luisdeveloper.billeteravirtualuq.controller.ModelFactoryController;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.CuentaDto;

import java.util.List;

public class MainBilleteraVirtualUq {

    public static void main(String[] args) {
        ModelFactoryController modelFactoryController = ModelFactoryController.getInstance();


        }

    
}
