package com.luisdeveloper.billeteravirtualuq.exceptions;

public class CuentaException extends Exception {

    public CuentaException(String mensaje) {
        super(mensaje);
    }
}
