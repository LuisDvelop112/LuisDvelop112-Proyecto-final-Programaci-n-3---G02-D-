package com.luisdeveloper.billeteravirtualuq.exceptions;

public class ArchivoNoEncontradoException extends Exception {

    public ArchivoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
