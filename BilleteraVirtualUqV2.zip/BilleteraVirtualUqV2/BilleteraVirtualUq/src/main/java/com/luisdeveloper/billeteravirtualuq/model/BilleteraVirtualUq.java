package com.luisdeveloper.billeteravirtualuq.model;

import com.luisdeveloper.billeteravirtualuq.exceptions.CuentaException;
import com.luisdeveloper.billeteravirtualuq.exceptions.TransaccionNoValidaException;
import com.luisdeveloper.billeteravirtualuq.exceptions.UsuarioNoEncontradoException;
import com.luisdeveloper.billeteravirtualuq.model.services.IBilleteraVirtualUqServices;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BilleteraVirtualUq implements IBilleteraVirtualUqServices, Serializable {

    private static final long serialVersionUID = 1L;
    ArrayList<Cuenta> listaCuentas = new ArrayList<>();
    ArrayList<Transaccion> listaTransacciones = new ArrayList<>();

    public BilleteraVirtualUq() {

    }


    public ArrayList<Cuenta> getListaCuentas() {
        return listaCuentas;
    }

    public void setListaCuentas(ArrayList<Cuenta> listaCuentas) {
        this.listaCuentas = listaCuentas;
    }




    @Override
    public Cuenta agregarCuenta(Cuenta nuevaCuenta) throws CuentaException {
        boolean cuentaExiste = verificarCuentaExistente(nuevaCuenta.getIdCuenta());
        if (cuentaExiste) {
            throw new CuentaException("La cuenta con id: " + nuevaCuenta.getIdCuenta() + " ya existe");
        } else {
            getListaCuentas().add(nuevaCuenta);
        }
        return nuevaCuenta;
    }
    

    public void agregarEmpleado(Cuenta nuevoEmpleado) throws CuentaException{
        getListaCuentas().add(nuevoEmpleado);
    }

    @Override
    public boolean actualizarCuenta(String idActual, Cuenta cuenta) throws CuentaException {
        Cuenta cuentaActual = obtenerCuenta(idActual);
        if(cuentaActual == null)
            throw new CuentaException("El cuenta a actualizar no existe");
        else{
            cuentaActual.setIdCuenta(cuenta.getIdCuenta());
            cuentaActual.setNombreBanco(cuenta.getNombreBanco());
            cuentaActual.setNumeroCuenta(cuenta.getNumeroCuenta());
            cuentaActual.setTipoCuenta(cuenta.getTipoCuenta());

            return true;
        }
    }

    @Override
    public Boolean eliminarCuenta(String idCuenta) throws CuentaException {
        Cuenta cuenta = null;
        boolean flagExiste = false;
        cuenta = obtenerCuenta(idCuenta);
        if(cuenta == null)
            throw new CuentaException("La cuenta a eliminar no existe");
        else{
            getListaCuentas().remove(cuenta);
            flagExiste = true;
        }
        return flagExiste;
    }

    @Override
    public boolean verificarCuentaExistente(String idCuenta) throws CuentaException {
        if(cuentaExiste(idCuenta)){
            throw new CuentaException("La cuenta con id: "+idCuenta+" ya existe");
        }else{
            return false;
        }
    }


    @Override
    public Cuenta obtenerCuenta(String idCuenta) {
        Cuenta cuentaEncontrado = null;
        for (Cuenta cuenta : getListaCuentas()) {
            if(cuenta.getIdCuenta().equalsIgnoreCase(idCuenta)){
                cuentaEncontrado = cuenta;
                break;
            }
        }
        return cuentaEncontrado;
    }

    @Override
    public ArrayList<Cuenta> obtenerCuentas() {
        // TODO Auto-generated method stub
        return getListaCuentas();
    }

    public boolean cuentaExiste(String idCuenta) {
        boolean cuentaEncontrado = false;
        for (Cuenta cuenta : getListaCuentas()) {
            if(cuenta.getIdCuenta().equalsIgnoreCase(idCuenta)){
                cuentaEncontrado = true;
                break;
            }
        }
        return cuentaEncontrado;
    }

private List<Usuario> listaUsuarios;

    public void agregarUsuario(Usuario usuario) {
        listaUsuarios.add(usuario);
    }

    public boolean eliminarUsuario(String idUsuario) throws UsuarioNoEncontradoException {
        Usuario usuario = obtenerUsuario(idUsuario);
        if (usuario != null) {
            listaUsuarios.remove(usuario);
            return true;
        }
        throw new UsuarioNoEncontradoException("Usuario no encontrado");
    }

    public void actualizarUsuario(String idUsuarioActual, Usuario usuarioActualizado) throws UsuarioNoEncontradoException {
        Usuario usuario = obtenerUsuario(idUsuarioActual);
        if (usuario != null) {
            listaUsuarios.remove(usuario);
            listaUsuarios.add(usuarioActualizado);
        } else {
            throw new UsuarioNoEncontradoException("Usuario no encontrado");
        }
    }

    public Usuario obtenerUsuario(String idUsuario) {
        return listaUsuarios.stream().filter(u -> u.getIdUsuario().equals(idUsuario)).findFirst().orElse(null);
    }

    public List<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }

    public boolean verificarUsuarioExistente(String idUsuario) {
        return listaUsuarios.stream().anyMatch(usuario -> usuario.getIdUsuario().equals(idUsuario));
    }

    public Transaccion agregarTransaccion(Transaccion nuevaTransaccion) throws TransaccionNoValidaException {
        if (verificarTransaccionExistente(nuevaTransaccion.getIdTransaccion())) {
            throw new TransaccionNoValidaException("La transacción con id: " + nuevaTransaccion.getIdTransaccion() + " ya existe");
        }
        listaTransacciones.add(nuevaTransaccion);
        return nuevaTransaccion;
    }

    public boolean eliminarTransaccion(String idTransaccion) throws TransaccionNoValidaException {
        Transaccion transaccion = obtenerTransaccion(idTransaccion);
        if (transaccion != null) {
            listaTransacciones.remove(transaccion);
            return true;
        }
        throw new TransaccionNoValidaException("Transacción no encontrada");
    }

    public boolean actualizarTransaccion(String idTransaccionActual, Transaccion transaccionActualizada) throws TransaccionNoValidaException {
        Transaccion transaccion = obtenerTransaccion(idTransaccionActual);
        if (transaccion != null) {
            eliminarTransaccion(idTransaccionActual); // Eliminar la transacción anterior
            listaTransacciones.add(transaccionActualizada); // Agregar la nueva
            return true;
        }
        throw new TransaccionNoValidaException("Transacción no encontrada");
    }

    public Transaccion obtenerTransaccion(String idTransaccion) {
        return listaTransacciones.stream()
                .filter(t -> t.getIdTransaccion().equals(idTransaccion))
                .findFirst()
                .orElse(null);
    }

    public boolean verificarTransaccionExistente(String idTransaccion) {
        return listaTransacciones.stream().anyMatch(t -> t.getIdTransaccion().equals(idTransaccion));
    }

    public List<Transaccion> getListaTransacciones() {
        return listaTransacciones;
    }
    
    
}
