package com.luisdeveloper.billeteravirtualuq.controller;

import com.luisdeveloper.billeteravirtualuq.controller.services.IModelFactoryService;
import com.luisdeveloper.billeteravirtualuq.exceptions.*;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.CuentaDto;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.TransaccionDto;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.UsuarioDto;
import com.luisdeveloper.billeteravirtualuq.mapping.mappers.BilleteraVirtualUqMapper;
import com.luisdeveloper.billeteravirtualuq.model.*;
import com.luisdeveloper.billeteravirtualuq.utils.Persistencia;
import com.luisdeveloper.billeteravirtualuq.utils.BilleteraVirtualUqUtils;

import java.io.IOException;
import java.util.List;

public class ModelFactoryController implements IModelFactoryService {

    BilleteraVirtualUq billeteraVirtualUq;
    BilleteraVirtualUqMapper mapper = BilleteraVirtualUqMapper.INSTANCE;

    // ------------------------------ Singleton --------------------------------
    private static class SingletonHolder {
        private final static ModelFactoryController eINSTANCE = new ModelFactoryController();
    }

    public static ModelFactoryController getInstance() {
        return SingletonHolder.eINSTANCE;
    }

    public ModelFactoryController()  {
        // Respaldar archivos al iniciar la aplicación
        Persistencia.respaldarArchivos();
        
        // Cargar datos desde archivo

       // cargarResourceXML();

      //  cargarResourceBinario();
        
        
        if (billeteraVirtualUq == null) {
            billeteraVirtualUq = BilleteraVirtualUqUtils.inicializarDatos();
            guardarResourceXML(); // Guardar en formato XML
            salvarDatosPrueba();
            guardarResourceBinario();
        }
    
        registrarAccionesSistema("Inicio de sesión", 1, "inicioSesion");
    }

        
    

    @SuppressWarnings("unused")
    private void salvarDatosPrueba() {
        try {
            Persistencia.guardarCuentas(getBilleteraVirtualUq().getListaCuentas());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public BilleteraVirtualUq getBilleteraVirtualUq() {
        return billeteraVirtualUq;
    }

    public void setBilleteraVirtualUq(BilleteraVirtualUq billeteraVirtualUq) {
        this.billeteraVirtualUq = billeteraVirtualUq;
    }

    @Override
    public boolean agregarUsuario(UsuarioDto usuarioDto) {
        if (!billeteraVirtualUq.verificarUsuarioExistente(usuarioDto.idUsuario())) {
            Usuario usuario = mapper.usuarioDtoToUsuario(usuarioDto);
            billeteraVirtualUq.agregarUsuario(usuario);
            registrarAccionesSistema("Se agregó el usuario " + usuario.getIdUsuario(), 1, "agregarUsuario");
            
            return true;
        }
        return false;
    }

    @Override
    public boolean eliminarUsuario(String idUsuario) {
        boolean flagExiste = false;
        try {
            flagExiste = billeteraVirtualUq.eliminarUsuario(idUsuario);
            registrarAccionesSistema("Se eliminó el usuario " + idUsuario, 1, "eliminarUsuario");
            
        } catch (UsuarioNoEncontradoException e) {
            e.printStackTrace();
        }
        return flagExiste;
    }

    @Override
    public boolean actualizarUsuario(String idUsuarioActual, UsuarioDto usuarioDto) {
        try {
            Usuario usuario = mapper.usuarioDtoToUsuario(usuarioDto);
            billeteraVirtualUq.actualizarUsuario(idUsuarioActual, usuario);
            registrarAccionesSistema("Se actualizó el usuario " + usuario.getIdUsuario(), 1, "actualizarUsuario");
            
            return true;
        } catch (UsuarioNoEncontradoException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public UsuarioDto obtenerUsuario(String idUsuario) {
        Usuario usuario = billeteraVirtualUq.obtenerUsuario(idUsuario);
        if (usuario != null) {
            registrarAccionesSistema("Se consultó el usuario " + idUsuario, 1, "obtenerUsuario");
            return mapper.usuarioToUsuarioDto(usuario);
        }
        return null;
    }

    @Override
    public List<UsuarioDto> obtenerUsuarios() {
        registrarAccionesSistema("Se consultaron todos los usuarios", 1, "obtenerUsuarios");
        return mapper.getUsuariosDto(billeteraVirtualUq.getListaUsuarios());
    }

    public boolean iniciarSesion(String Idusuario, String contrasena) {
        Usuario usuario = billeteraVirtualUq.obtenerUsuario(Idusuario);
        if (usuario != null && usuario.getContrasena().equals(contrasena)) {
            registrarAccionesSistema("Inicio de sesión exitoso para " + usuario.getIdUsuario(), 1, "inicioSesion");
            return true;
        } else {
            registrarAccionesSistema("Intento de inicio de sesión fallido para " + Idusuario, 2, "inicioSesion");
            return false;
        }
    }

    @Override
    public List<CuentaDto> obtenerCuentas() {
        registrarAccionesSistema("Se consultaron todas las cuentas", 1, "obtenerCuentas");
        return mapper.getCuentasDto(billeteraVirtualUq.getListaCuentas());
    }

    @Override
public boolean agregarCuenta(CuentaDto cuentaDto) {
    try {
        if (!billeteraVirtualUq.verificarCuentaExistente(cuentaDto.idCuenta())) {
            Cuenta cuenta = mapper.cuentaDtoToCuenta(cuentaDto);
            getBilleteraVirtualUq().agregarCuenta(cuenta);
            registrarAccionesSistema("Se agregó la cuenta " + cuenta.getIdCuenta(), 1, "agregarCuenta");
        
        }
        return true;
    } catch (CuentaException e) {
        String mensajeError = "Error al agregar cuenta: " + e.getMessage();
        registrarAccionesSistema(mensajeError, 2, "errorAgregarCuenta");
        e.printStackTrace();
        return false;
    }
}


    @Override
    public boolean eliminarCuenta(String idCuenta) {
        boolean flagExiste = false;
        try {
            flagExiste = getBilleteraVirtualUq().eliminarCuenta(idCuenta);
            registrarAccionesSistema("Se eliminó la cuenta " + idCuenta, 1, "eliminarCuenta");
            
        } catch (CuentaException e) {
            e.printStackTrace();
        }
        return flagExiste;
    }

    @Override
    public boolean actualizarCuenta(String idCuentaActual, CuentaDto cuentaDto) {
        try {
            Cuenta cuenta = mapper.cuentaDtoToCuenta(cuentaDto);
            getBilleteraVirtualUq().actualizarCuenta(idCuentaActual, cuenta);
            registrarAccionesSistema("Se actualizó la cuenta " + cuenta.getIdCuenta(), 1, "actualizarCuenta");
            return true;
        } catch (CuentaException e) {
            e.printStackTrace();
            return false;
        }
    }

    @SuppressWarnings("unused")
    private void cargarResourceXML() {
        try {
            billeteraVirtualUq = Persistencia.cargarRecursoXML();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void guardarResourceXML() {
        try {
            Persistencia.guardarRecursoXML(billeteraVirtualUq);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void cargarResourceBinario() {
        try {
            System.out.println("prueba");
            billeteraVirtualUq = Persistencia.cargarRecursoBinario();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void guardarResourceBinario() {
        try {
            Persistencia.guardarRecursoBinario(billeteraVirtualUq);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void registrarAccionesSistema(String mensaje, int nivel, String accion) {
        Persistencia.guardaRegistroLog(mensaje, nivel, accion);
    }

    @Override
    public boolean agregarTransaccion(TransaccionDto transaccionDto) {
        try {
            if (!billeteraVirtualUq.verificarTransaccionExistente(transaccionDto.idTransaccion())) {
                Transaccion transaccion = mapper.transaccionDtoToTransaccion(transaccionDto);
                billeteraVirtualUq.agregarTransaccion(transaccion);
                registrarAccionesSistema("Se agregó la transacción " + transaccion.getIdTransaccion(), 1, "agregarTransaccion");
                
                return true;
            }
        } catch (TransaccionNoValidaException e) {
            e.printStackTrace();
            return false;
        }
        return false; // La transacción ya existe
    }

    @Override
    public boolean eliminarTransaccion(String idTransaccion) {
        boolean flagExiste = false;
        try {
            flagExiste = billeteraVirtualUq.eliminarTransaccion(idTransaccion);
            registrarAccionesSistema("Se eliminó la transacción " + idTransaccion, 1, "eliminarTransaccion");
            
        } catch (TransaccionNoValidaException e) {
            e.printStackTrace();
        }
        return flagExiste;
    }

    @Override
    public boolean actualizarTransaccion(String idTransaccionActual, TransaccionDto transaccionDto) {
        try {
            Transaccion transaccion = mapper.transaccionDtoToTransaccion(transaccionDto);
            billeteraVirtualUq.actualizarTransaccion(idTransaccionActual, transaccion);
            registrarAccionesSistema("Se actualizó la transacción " + transaccion.getIdTransaccion(), 1, "actualizarTransaccion");
            return true;
        } catch (TransaccionNoValidaException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<TransaccionDto> obtenerTransacciones() {
        registrarAccionesSistema("Se consultaron todas las transacciones", 1, "obtenerTransacciones");
        return mapper.getTransaccionesDto(billeteraVirtualUq.getListaTransacciones());
    }

    // ... Métodos de carga y guardado de datos ...
    
    
}
