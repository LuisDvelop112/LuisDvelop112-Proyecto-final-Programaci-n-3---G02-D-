package com.luisdeveloper.billeteravirtualuq.controller.services;

import com.luisdeveloper.billeteravirtualuq.mapping.dto.TransaccionDto;

import java.util.List;

public interface ITransaccionControllerService {
    List<TransaccionDto> obtenerTransacciones();

    boolean agregarTransaccion(TransaccionDto transaccionDto);

    boolean eliminarTransaccion(String idTransaccion);

    boolean actualizarTransaccion(String idTransaccionActual, TransaccionDto transaccionDto);
}
