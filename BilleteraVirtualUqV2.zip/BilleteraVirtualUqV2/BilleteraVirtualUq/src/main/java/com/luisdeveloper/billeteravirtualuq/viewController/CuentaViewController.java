package com.luisdeveloper.billeteravirtualuq.viewController;

import com.luisdeveloper.billeteravirtualuq.controller.CuentaController;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.CuentaDto;
import com.luisdeveloper.billeteravirtualuq.model.Cuenta;
import com.luisdeveloper.billeteravirtualuq.utils.Persistencia;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

public class CuentaViewController {

    private CuentaController cuentaControllerService;
    private ObservableList<CuentaDto> listaCuentasDto = FXCollections.observableArrayList();
    private CuentaDto cuentaSeleccionada;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField txtCuentaId;

    @FXML
    private TextField txtNumeroCuenta;

    @FXML
    private TextField txtNombreBanco;

    @FXML
    private TextField txtTipoCuenta;

    @FXML
    private Button btnActualizar;

    @FXML
    private Button btnNuevo;

    @FXML
    private Button btnAgregar;

    @FXML
    private Button btnEliminar;

    @FXML
    private TableView<CuentaDto> tableCuentas;

    @FXML
    private TableColumn<CuentaDto, String> tcCuentaId;

    @FXML
    private TableColumn<CuentaDto, String> tcNombreBanco;

    @FXML
    private TableColumn<CuentaDto, String> tcNumeroCuenta;

    @FXML
    private TableColumn<CuentaDto, String> tcTipoCuenta;

    @FXML
    void initialize() {
        cuentaControllerService = new CuentaController();
        initView();
    }

    private void initView() {
        initDataBinding();
        obtenerCuenta();
        tableCuentas.getItems().clear();
        tableCuentas.setItems(listaCuentasDto);
        //cargarArchivostxt();
        
        listenerSelection();
    }

    private void initDataBinding() {
        tcCuentaId.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().idCuenta()));
        tcNombreBanco.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().nombreBanco()));
        tcNumeroCuenta.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().numeroCuenta()));
        tcTipoCuenta.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().tipoCuenta()));
    }

    private void obtenerCuenta() {
        listaCuentasDto.addAll(cuentaControllerService.obtenerCuentas());
    }

    private void cargarArchivostxt() {
        listaCuentasDto.clear(); // Limpiar la lista existente
        ArrayList<Cuenta> cuentas = new ArrayList<>();
        try {
            cuentas = Persistencia.cargarCuentas();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } // Cargar las cuentas desde el archivo
        for (Cuenta cuenta : cuentas) {
            // Convertir cada Cuenta a CuentaDto y agregar a listaCuentasDto
            CuentaDto cuentaDto = new CuentaDto(cuenta.getIdCuenta(), cuenta.getNumeroCuenta(), cuenta.getNombreBanco(),
                    cuenta.getTipoCuenta());
            listaCuentasDto.add(cuentaDto);
        }
        tableCuentas.setItems(listaCuentasDto); // Actualizar la tabla
    }

    private void listenerSelection() {
        tableCuentas.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            cuentaSeleccionada = newSelection;
            mostrarInformacionCuenta(cuentaSeleccionada);
        });
    }

    private void mostrarInformacionCuenta(CuentaDto cuentaSeleccionada) {
        if (cuentaSeleccionada != null) {
            txtCuentaId.setText(cuentaSeleccionada.idCuenta());
            txtNumeroCuenta.setText(cuentaSeleccionada.numeroCuenta());
            txtNombreBanco.setText(cuentaSeleccionada.nombreBanco());
            txtTipoCuenta.setText(cuentaSeleccionada.tipoCuenta());
        }
    }

    @FXML
    void nuevoCuentaAction(ActionEvent event) {
        limpiarCamposCuenta();
    }

    @FXML
    void agregarCuentaAction(ActionEvent event) {
        crearCuenta();
    }

    @FXML
    void eliminarCuentaAction(ActionEvent event) {
        eliminarCuenta();
    }

    @FXML
    void actualizarCuentaAction(ActionEvent event) {
        actualizarCuenta();
    }

    private void crearCuenta() {
        CuentaDto cuentaDto = construirCuentaDto();
        if (datosValidos(cuentaDto)) {
            if (cuentaControllerService.agregarCuenta(cuentaDto)) {
                listaCuentasDto.add(cuentaDto);
                mostrarMensaje("Notificación Cuenta", "Cuenta creada", "La cuenta se ha creado con éxito", Alert.AlertType.INFORMATION);
                limpiarCamposCuenta();
            } else {
                mostrarMensaje("Notificación Cuenta", "Error", "La cuenta no se ha creado", Alert.AlertType.ERROR);
            }
        }
    }

    private void eliminarCuenta() {
        if (cuentaSeleccionada != null) {
            if (mostrarMensajeConfirmacion("¿Estás seguro de eliminar la cuenta?")) {
                if (cuentaControllerService.eliminarCuenta(cuentaSeleccionada.idCuenta())) {
                    listaCuentasDto.remove(cuentaSeleccionada);
                    limpiarCamposCuenta();
                    mostrarMensaje("Notificación Cuenta", "Cuenta eliminada", "La cuenta se ha eliminado con éxito", Alert.AlertType.INFORMATION);
                } else {
                    mostrarMensaje("Notificación Cuenta", "Error", "La cuenta no se ha podido eliminar", Alert.AlertType.ERROR);
                }
            }
        } else {
            mostrarMensaje("Notificación Cuenta", "Cuenta no seleccionada", "Selecciona una cuenta de la lista", Alert.AlertType.WARNING);
        }
    }

    private void actualizarCuenta() {
        if (cuentaSeleccionada != null) {
            CuentaDto cuentaDto = construirCuentaDto();
            if (datosValidos(cuentaDto)) {
                if (cuentaControllerService.actualizarCuenta(cuentaSeleccionada.idCuenta(), cuentaDto)) {
                    listaCuentasDto.set(listaCuentasDto.indexOf(cuentaSeleccionada), cuentaDto);
                    tableCuentas.refresh();
                    mostrarMensaje("Notificación Cuenta", "Cuenta actualizada", "La cuenta se ha actualizado con éxito", Alert.AlertType.INFORMATION);
                    limpiarCamposCuenta();
                } else {
                    mostrarMensaje("Notificación Cuenta", "Error", "La cuenta no se ha actualizado", Alert.AlertType.ERROR);
                }
            }
        } else {
            mostrarMensaje("Notificación Cuenta", "Cuenta no seleccionada", "Selecciona una cuenta para actualizar", Alert.AlertType.WARNING);
        }
    }

    private CuentaDto construirCuentaDto() {
        return new CuentaDto(
                txtCuentaId.getText(),
                txtNumeroCuenta.getText(),
                txtNombreBanco.getText(),
                txtTipoCuenta.getText()
        );
    }

    private void limpiarCamposCuenta() {
        txtCuentaId.clear();
        txtNumeroCuenta.clear();
        txtNombreBanco.clear();
        txtTipoCuenta.clear();
    }

    private boolean datosValidos(CuentaDto cuentaDto) {
        String mensaje = "";
        if (cuentaDto.idCuenta().isEmpty()) mensaje += "El ID es inválido\n";
        if (cuentaDto.nombreBanco().isEmpty()) mensaje += "El nombre del banco es inválido\n";
        if (cuentaDto.numeroCuenta().isEmpty()) mensaje += "El número de cuenta es inválido\n";
        if (cuentaDto.tipoCuenta().isEmpty()) mensaje += "El tipo de cuenta es inválido\n";

        if (!mensaje.isEmpty()) {
            mostrarMensaje("Notificación Cuenta", "Datos inválidos", mensaje, Alert.AlertType.WARNING);
            return false;
        }
        return true;
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(titulo);
        alert.setHeaderText(header);
        alert.setContentText(contenido);
        alert.showAndWait();
    }

    private boolean mostrarMensajeConfirmacion(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmación");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        Optional<ButtonType> action = alert.showAndWait();
        return action.isPresent() && action.get() == ButtonType.OK;
    }
}

