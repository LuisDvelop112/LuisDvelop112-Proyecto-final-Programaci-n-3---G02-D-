package com.luisdeveloper.billeteravirtualuq.exceptions;

public class ConexionServidorException extends Exception {

    public ConexionServidorException(String mensaje) {
        super(mensaje);
    }
}
