package com.luisdeveloper.billeteravirtualuq.controller;

import com.luisdeveloper.billeteravirtualuq.controller.services.IModelFactoryService;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.UsuarioDto;

import java.util.List;

public class UsuarioController {

    // Instancia de la capa de servicios
    private final IModelFactoryService modelFactoryService;

    // Constructor que recibe la instancia de servicio
    public UsuarioController() {
        this.modelFactoryService = ModelFactoryController.getInstance();
    }

    // Método para agregar un usuario
    public boolean agregarUsuario(UsuarioDto usuarioDto) {
        return modelFactoryService.agregarUsuario(usuarioDto);
    }

    // Método para eliminar un usuario por ID
    public boolean eliminarUsuario(String idUsuario) {
        return modelFactoryService.eliminarUsuario(idUsuario);
    }

    // Método para actualizar un usuario
    public boolean actualizarUsuario(String idUsuarioActual, UsuarioDto usuarioDto) {
        return modelFactoryService.actualizarUsuario(idUsuarioActual, usuarioDto);
    }

    // Método para obtener un usuario por ID
    public UsuarioDto obtenerUsuario(String idUsuario) {
        return modelFactoryService.obtenerUsuario(idUsuario);
    }

    // Método para obtener la lista de usuarios
    public List<UsuarioDto> obtenerUsuarios() {
        return modelFactoryService.obtenerUsuarios();
    }

    public boolean iniciarSesion(String correoElectronico, String contrasena) {
        // Se delega la lógica al servicio
        return modelFactoryService.iniciarSesion(correoElectronico, contrasena);
    }
}
