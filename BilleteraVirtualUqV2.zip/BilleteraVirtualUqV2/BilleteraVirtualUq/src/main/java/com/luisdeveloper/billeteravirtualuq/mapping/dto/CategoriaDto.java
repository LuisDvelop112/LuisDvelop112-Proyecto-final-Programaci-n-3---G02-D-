package com.luisdeveloper.billeteravirtualuq.mapping.dto;

public record CategoriaDto(
        String idCategoria,
        String nombre,
        String descripcion) {
}
