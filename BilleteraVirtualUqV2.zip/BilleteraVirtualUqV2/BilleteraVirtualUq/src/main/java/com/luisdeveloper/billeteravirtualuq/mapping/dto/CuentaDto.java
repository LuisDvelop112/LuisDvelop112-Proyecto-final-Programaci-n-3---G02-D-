package com.luisdeveloper.billeteravirtualuq.mapping.dto;

public record CuentaDto(

        String idCuenta,

        String nombreBanco,

        String numeroCuenta,

        String tipoCuenta) {
}
