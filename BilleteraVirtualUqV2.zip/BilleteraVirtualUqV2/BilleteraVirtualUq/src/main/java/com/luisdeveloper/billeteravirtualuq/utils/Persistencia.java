package com.luisdeveloper.billeteravirtualuq.utils;

import com.luisdeveloper.billeteravirtualuq.model.Cuenta;
import com.luisdeveloper.billeteravirtualuq.model.BilleteraVirtualUq;
import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class Persistencia {

    public static final String RUTA_BASE = "C:/td/persistencia/";
    public static final String RUTA_ARCHIVOS = RUTA_BASE + "archivos/";
    public static final String RUTA_RESPALDO = RUTA_BASE + "respaldo/";
    public static final String RUTA_LOG = RUTA_BASE + "log/";

    // Archivos de persistencia
    public static final String ARCHIVO_CUENTAS = RUTA_ARCHIVOS + "cuentas.txt";
    public static final String ARCHIVO_TRANSACCIONES = RUTA_ARCHIVOS + "objeto_Transaccion.txt";
    public static final String ARCHIVO_LOG = RUTA_LOG + "BilleteraVirtualUqLog.txt";
    
    // Archivos binarios y XML del modelo
    public static final String RUTA_ARCHIVO_MODELO_BINARIO = RUTA_BASE + "model.dat";
    public static final String RUTA_ARCHIVO_MODELO_XML = "C:\\td\\Persistencia\\model.xml";

    public static void respaldarArchivos() {
        try {
            // Crear la carpeta de respaldo si no existe
            Files.createDirectories(Paths.get(RUTA_RESPALDO));

            // Respaldar archivo XML
            Path archivoXmlOriginal = Paths.get(RUTA_ARCHIVO_MODELO_XML);
            Path archivoXmlRespaldo = Paths.get(RUTA_RESPALDO + "model_backup_" + System.currentTimeMillis() + ".xml");
            Files.copy(archivoXmlOriginal, archivoXmlRespaldo, StandardCopyOption.REPLACE_EXISTING);

            // Respaldar archivo binario
            Path archivoBinarioOriginal = Paths.get(RUTA_ARCHIVO_MODELO_BINARIO);
            Path archivoBinarioRespaldo = Paths.get(RUTA_RESPALDO + "model_backup_" + System.currentTimeMillis() + ".dat");
            Files.copy(archivoBinarioOriginal, archivoBinarioRespaldo, StandardCopyOption.REPLACE_EXISTING);

            System.out.println("Archivos respaldados correctamente.");
        } catch (IOException e) {
            System.out.println("Error al respaldar archivos: " + e.getMessage());
        }
    }
    // Cargar datos de archivos
    public static List<Cuenta> cargarDatosArchivos(BilleteraVirtualUq billeteraVirtualUq) throws FileNotFoundException, IOException {
        ArrayList<Cuenta> cuentasCargadas = cargarCuentas();
        if (cuentasCargadas.size() > 0) {
            billeteraVirtualUq.getListaCuentas().addAll(cuentasCargadas);
        }
        return cuentasCargadas;
    }

    // Guardar cuentas en formato: idCuenta@@nombreBanco@@numeroCuenta@@tipoCuenta
    public static void guardarCuentas(List<Cuenta> listaCuentas) throws IOException {
        StringBuilder contenido = new StringBuilder();
        for (Cuenta cuenta : listaCuentas) {
            contenido.append(cuenta.getIdCuenta()).append("@@")
                    .append(cuenta.getNombreBanco()).append("@@")
                    .append(cuenta.getNumeroCuenta()).append("@@")
                    .append(cuenta.getTipoCuenta()).append("\n");
        }
        ArchivoUtil.guardarArchivo(ARCHIVO_CUENTAS, contenido.toString(), false);
    }

    // Cargar cuentas desde archivo
    public static ArrayList<Cuenta> cargarCuentas() throws FileNotFoundException, IOException {
        ArrayList<Cuenta> cuentas = new ArrayList<>();
        ArrayList<String> contenido = ArchivoUtil.leerArchivo(ARCHIVO_CUENTAS);
        for (String linea : contenido) {
            String[] datos = linea.split("@@");
            Cuenta cuenta = new Cuenta();
            cuenta.setIdCuenta(datos[0]);
            cuenta.setNombreBanco(datos[1]);
            cuenta.setNumeroCuenta(datos[2]);
            cuenta.setTipoCuenta(datos[3]);
            cuentas.add(cuenta);
        }
        return cuentas;
    }

    // Guardar transacciones en formato: numeroTransaccion@@hora@@fecha@@valor@@numeroCuenta@@cedulaCliente@@codigoEmpleado
/*     public static void guardarTransacciones(List<Transaccion> listaTransacciones) throws IOException {
        StringBuilder contenido = new StringBuilder();
        for (Transaccion transaccion : listaTransacciones) {
            contenido.append(transaccion.getNumeroTransaccion()).append("@@")
                    .append(transaccion.getHora()).append("@@")
                    .append(transaccion.getFecha()).append("@@")
                    .append(transaccion.getValor()).append("@@")
                    .append(transaccion.getCuenta().getNumeroCuenta()).append("@@")
                    .append(transaccion.getCliente().getCedula()).append("@@")
                    .append(transaccion.getEmpleado().getCodigoEmpleado()).append("\n");
        }
        ArchivoUtil.guardarArchivo(ARCHIVO_TRANSACCIONES, contenido.toString(), false);
        respaldarTransacciones();
    }
*/

    // Respaldo de transacciones
    @SuppressWarnings("unused")
    private static void respaldarTransacciones() throws IOException {
        Path origen = Paths.get(ARCHIVO_TRANSACCIONES);
        String nombreRespaldo = "backup_" + obtenerFechaHora() + ".txt";
        Path destino = Paths.get(RUTA_RESPALDO + nombreRespaldo);
        Files.createDirectories(destino.getParent());
        Files.copy(origen, destino, StandardCopyOption.REPLACE_EXISTING);
    }

    // Obtener la fecha y hora actual en formato ddmmaaa_hhmmss
    private static String obtenerFechaHora() {
        return new java.text.SimpleDateFormat("ddMMyyyy_HHmmss").format(new java.util.Date());
    }

    // Registrar acciones en el log
    public static void guardaRegistroLog(String mensajeLog, int nivel, String accion) {
        ArchivoUtil.guardarRegistroLog(mensajeLog, nivel, accion, ARCHIVO_LOG);
    }

    // Guardar y cargar recursos binarios y XML del modelo
    public static BilleteraVirtualUq cargarRecursoBinario() throws Exception {
        return (BilleteraVirtualUq) ArchivoUtil.cargarRecursoSerializado(RUTA_ARCHIVO_MODELO_BINARIO);
    }

    public static void guardarRecursoBinario(BilleteraVirtualUq billeteraVirtualUq) throws Exception {
        ArchivoUtil.salvarRecursoSerializado(RUTA_ARCHIVO_MODELO_BINARIO, billeteraVirtualUq);
    }

    public static BilleteraVirtualUq cargarRecursoXML() throws IOException {
        return (BilleteraVirtualUq) ArchivoUtil.cargarRecursoSerializadoXML(RUTA_ARCHIVO_MODELO_XML);
    }

    public static void guardarRecursoXML(BilleteraVirtualUq billeteraVirtualUq) throws IOException {
        ArchivoUtil.salvarRecursoSerializadoXML(RUTA_ARCHIVO_MODELO_XML, billeteraVirtualUq);
    }
}
