package com.luisdeveloper.billeteravirtualuq.exceptions;

public class PresupuestoExcedidoException extends Exception {

    public PresupuestoExcedidoException(String mensaje) {
        super(mensaje);
    }
}
