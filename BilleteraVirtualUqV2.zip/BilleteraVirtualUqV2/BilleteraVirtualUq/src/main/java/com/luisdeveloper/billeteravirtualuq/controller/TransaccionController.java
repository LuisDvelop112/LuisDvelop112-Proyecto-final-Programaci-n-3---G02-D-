package com.luisdeveloper.billeteravirtualuq.controller;

import com.luisdeveloper.billeteravirtualuq.controller.services.ITransaccionControllerService;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.TransaccionDto;
import java.util.List;

public class TransaccionController implements ITransaccionControllerService {

    ModelFactoryController modelFactoryController;

    public TransaccionController() {
        modelFactoryController = ModelFactoryController.getInstance();
    }

    @Override
    public List<TransaccionDto> obtenerTransacciones() {
        return modelFactoryController.obtenerTransacciones();
    }

    @Override
    public boolean agregarTransaccion(TransaccionDto transaccion) {
        return modelFactoryController.agregarTransaccion(transaccion);
    }

    @Override
    public boolean eliminarTransaccion(String idTransaccion) {
        return modelFactoryController.eliminarTransaccion(idTransaccion);
    }

    @Override
    public boolean actualizarTransaccion(String idTransaccionActual, TransaccionDto transaccionDto) {
        return modelFactoryController.actualizarTransaccion(idTransaccionActual, transaccionDto);
    }
}
