package com.luisdeveloper.billeteravirtualuq.model;

import java.util.Objects;

public class Usuario {

    private String idUsuario;
    private String nombreCompleto;
    private String correoElectronico;
    private String numeroTelefono;
    private String direccion;
    private double saldoTotal;
    private String contrasena; // Nuevo atributo para la contraseña

    public Usuario(String idUsuario, String nombreCompleto, String correoElectronico, String numeroTelefono, String direccion, double saldoTotal, String contrasena) {
        this.idUsuario = idUsuario;
        this.nombreCompleto = nombreCompleto;
        this.correoElectronico = correoElectronico;
        this.numeroTelefono = numeroTelefono;
        this.direccion = direccion;
        this.saldoTotal = saldoTotal;
        this.contrasena = contrasena; // Inicialización de la contraseña
    }

    public Usuario() {
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getNumeroTelefono() {
        return numeroTelefono;
    }

    public void setNumeroTelefono(String numeroTelefono) {
        this.numeroTelefono = numeroTelefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getSaldoTotal() {
        return saldoTotal;
    }

    public void setSaldoTotal(double saldoTotal) {
        this.saldoTotal = saldoTotal;
    }

    public String getContrasena() { // Getter para la contraseña
        return contrasena;
    }

    public void setContrasena(String contrasena) { // Setter para la contraseña
        this.contrasena = contrasena;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return Double.compare(usuario.saldoTotal, saldoTotal) == 0 &&
            Objects.equals(idUsuario, usuario.idUsuario) &&
            Objects.equals(nombreCompleto, usuario.nombreCompleto) &&
            Objects.equals(correoElectronico, usuario.correoElectronico) &&
            Objects.equals(numeroTelefono, usuario.numeroTelefono) &&
            Objects.equals(direccion, usuario.direccion) &&
            Objects.equals(contrasena, usuario.contrasena); // Comparar contrasena en equals
    }

    @Override
    public int hashCode() {
        return Objects.hash(idUsuario, nombreCompleto, correoElectronico, numeroTelefono, direccion, saldoTotal, contrasena); // Incluir contrasena en hashCode
    }

    @Override
    public String toString() {
        return "Usuario{" +
            "idUsuario='" + idUsuario + '\'' +
            ", nombreCompleto='" + nombreCompleto + '\'' +
            ", correoElectronico='" + correoElectronico + '\'' +
            ", numeroTelefono='" + numeroTelefono + '\'' +
            ", direccion='" + direccion + '\'' +
            ", saldoTotal=" + saldoTotal +
            ", contrasena='" + contrasena + '\'' + // Evitar mostrar contrasena en toString por razones de seguridad
            '}';
    }
}
