package com.luisdeveloper.billeteravirtualuq.exceptions;

public class CategoriaNoEncontradaException extends Exception {

    public CategoriaNoEncontradaException(String mensaje) {
        super(mensaje);
    }
}
