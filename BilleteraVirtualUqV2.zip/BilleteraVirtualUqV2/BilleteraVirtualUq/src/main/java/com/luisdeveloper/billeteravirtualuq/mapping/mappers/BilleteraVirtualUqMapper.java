package com.luisdeveloper.billeteravirtualuq.mapping.mappers;

import com.luisdeveloper.billeteravirtualuq.mapping.dto.CategoriaDto;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.CuentaDto;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.PresupuestoDto;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.TransaccionDto;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.UsuarioDto;
import com.luisdeveloper.billeteravirtualuq.model.Cuenta;
import com.luisdeveloper.billeteravirtualuq.model.Presupuesto;
import com.luisdeveloper.billeteravirtualuq.model.Transaccion;
import com.luisdeveloper.billeteravirtualuq.model.Usuario;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface BilleteraVirtualUqMapper {

    BilleteraVirtualUqMapper INSTANCE = Mappers.getMapper(BilleteraVirtualUqMapper.class);

    // Mapeo para Cuenta
    @Named("cuentaToCuentaDto")
    CuentaDto cuentaToCuentaDto(Cuenta cuenta);

    Cuenta cuentaDtoToCuenta(CuentaDto cuentaDto);

    @IterableMapping(qualifiedByName = "cuentaToCuentaDto")
    List<CuentaDto> getCuentasDto(List<Cuenta> listaCuentas);

    // Mapeo para Usuario
    
    @Named("usuarioToUsuarioDto")
    @Mapping(target = "cuentasBancarias", ignore = true)
    UsuarioDto usuarioToUsuarioDto(Usuario usuario);

    Usuario usuarioDtoToUsuario(UsuarioDto usuarioDto);

    @IterableMapping(qualifiedByName = "usuarioToUsuarioDto")
    List<UsuarioDto> getUsuariosDto(List<Usuario> listaUsuarios);

    // Mapeo para Transacción
    @Named("transaccionToTransaccionDto")
    TransaccionDto transaccionToTransaccionDto(Transaccion transaccion);

    Transaccion transaccionDtoToTransaccion(TransaccionDto transaccionDto);

    @IterableMapping(qualifiedByName = "transaccionToTransaccionDto")
    List<TransaccionDto> getTransaccionesDto(List<Transaccion> listaTransacciones);

    // Mapeo para Presupuesto
    @Named("presupuestoToPresupuestoDto")
    PresupuestoDto presupuestoToPresupuestoDto(Presupuesto presupuesto);

    Presupuesto presupuestoDtoToPresupuesto(PresupuestoDto presupuestoDto);

    @IterableMapping(qualifiedByName = "presupuestoToPresupuestoDto")
    List<PresupuestoDto> getPresupuestosDto(List<Presupuesto> listaPresupuestos);

    // Mapeo para Categoría
    @Named("categoriaToCategoriaDto")
    CategoriaDto categoriaToCategoriaDto(CategoriaDto categoria);

    CategoriaDto categoriaDtoToCategoria(CategoriaDto categoriaDto);

    @IterableMapping(qualifiedByName = "categoriaToCategoriaDto")
    List<CategoriaDto> getCategoriasDto(List<CategoriaDto> listaCategorias);

}
