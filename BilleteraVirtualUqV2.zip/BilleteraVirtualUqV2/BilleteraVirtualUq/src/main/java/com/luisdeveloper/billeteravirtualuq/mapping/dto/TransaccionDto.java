package com.luisdeveloper.billeteravirtualuq.mapping.dto;

import java.util.Date;

public record TransaccionDto(
        String idTransaccion,
        Date fecha,
        String tipoTransaccion, // Depósito, Retiro, Transferencia
        double monto,
        String descripcion,
        CuentaDto cuentaOrigen,
        CuentaDto cuentaDestino) {
}
