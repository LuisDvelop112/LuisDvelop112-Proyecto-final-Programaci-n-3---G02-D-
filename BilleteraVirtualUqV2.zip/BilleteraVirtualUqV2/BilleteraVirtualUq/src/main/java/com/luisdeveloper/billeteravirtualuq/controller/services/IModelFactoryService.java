package com.luisdeveloper.billeteravirtualuq.controller.services;

import com.luisdeveloper.billeteravirtualuq.mapping.dto.CuentaDto;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.TransaccionDto;
import com.luisdeveloper.billeteravirtualuq.mapping.dto.UsuarioDto;

import java.util.List;

public interface IModelFactoryService {

    List<CuentaDto> obtenerCuentas();

    boolean agregarCuenta(CuentaDto cuentaDto);

    boolean eliminarCuenta(String idCuenta);

    boolean actualizarCuenta(String idCuentaActual, CuentaDto cuentaDto);

    boolean agregarUsuario(UsuarioDto usuarioDto);

    boolean eliminarUsuario(String idUsuario);

    boolean actualizarUsuario(String idUsuarioActual, UsuarioDto usuarioDto);

    UsuarioDto obtenerUsuario(String idUsuario);

    List<UsuarioDto> obtenerUsuarios();

    boolean iniciarSesion(String correoElectronico, String contrasena);

    boolean actualizarTransaccion(String idTransaccionActual, TransaccionDto transaccionDto);

    List<TransaccionDto> obtenerTransacciones();

    boolean eliminarTransaccion(String idTransaccion);

    boolean agregarTransaccion(TransaccionDto transaccionDto);
}
