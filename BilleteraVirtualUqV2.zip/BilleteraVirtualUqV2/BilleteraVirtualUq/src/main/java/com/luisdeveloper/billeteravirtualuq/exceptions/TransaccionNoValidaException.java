package com.luisdeveloper.billeteravirtualuq.exceptions;

public class TransaccionNoValidaException extends Exception {

    public TransaccionNoValidaException(String mensaje) {
        super(mensaje);
    }
}
